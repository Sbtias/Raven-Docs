/* Índice de búsqueda generado desde los títulos y las entradas de cada página. */
window.RAVEN_SEARCH = [
 {
  "t": "Raven, documentado de principio a fin.",
  "page": "index.html",
  "hash": "",
  "text": "Documentación completa de Raven: instalación, primeros pasos, XML, XMLC, temas, glass, widgets, herramientas, API de C y bindings para C++, Python, Rust, Go, C#, Zig y LuaJIT."
 },
 {
  "t": "¿Qué es Raven?",
  "page": "index.html",
  "hash": "que-es",
  "text": "Raven es una librería de interfaz gráfica retained-mode escrita en C11. El árbol de widgets se conserva entre frames; solo se vuelve a medir, pintar y presentar lo que cambió. La aplicación escribe su propio bucle y pide un frame cada vez con Rdraw_frame() o R"
 },
 {
  "t": "Lo que trae",
  "page": "index.html",
  "hash": "caracteristicas",
  "text": "VBox, HBox, Grid, Overlay, Border, Canvas, ScrollBox, Splitter, WrapBox, Switcher, TabView, Expander y DockArea. Cada hijo lleva su slot: relleno, alineación, tamaño."
 },
 {
  "t": "Visto en acción",
  "page": "index.html",
  "hash": "galeria",
  "text": ""
 },
 {
  "t": "Empieza en dos minutos",
  "page": "index.html",
  "hash": "inicio-rapido",
  "text": "Con este paquete precompilado para Windows (MinGW-w64 x64, estático) solo necesitas un compilador de MinGW y CMake. La guía de instalación explica también cómo compilar desde el código fuente y cómo usar el paquete desde Visual Studio."
 },
 {
  "t": "Explora la documentación",
  "page": "index.html",
  "hash": "explorar",
  "text": "Instalación, primera ventana, bucle, layout, ventanas, eventos, memoria, hilos, animaciones, diálogos y viewports."
 },
 {
  "t": "De cero a una ventana que funciona",
  "page": "guia.html",
  "hash": "",
  "text": "Instalación de Raven, primera ventana, bucle de frames, layout, ventanas nativas, eventos, memoria, hilos, animaciones, diálogos y viewports."
 },
 {
  "t": "Instalación",
  "page": "guia.html",
  "hash": "instalacion",
  "text": "Raven se distribuye como un paquete CMake. En Windows conviven cuatro variantes: Visual C++ y MinGW-w64, cada una estática y compartida. Las bibliotecas de un compilador no sirven para el otro. Este paquete es MinGW-w64 x64, estático."
 },
 {
  "t": "Tu primera ventana",
  "page": "guia.html",
  "hash": "primera-ventana",
  "text": "El programa mínimo: iniciar, crear una ventana, darle contenido y esperar frames hasta que el usuario cierre."
 },
 {
  "t": "El bucle de frames",
  "page": "guia.html",
  "hash": "bucle",
  "text": "Raven no tiene bucle propio. Tú decides cuándo se produce un frame:"
 },
 {
  "t": "Handles, errores y nombres",
  "page": "guia.html",
  "hash": "conceptos",
  "text": "Ventanas, widgets, fuentes, texturas, timers, documentos XML y nodos son handles opacos de 32 bits. Llevan un contador de generación, así que usar un objeto borrado se detecta y se reporta en vez de provocar un acceso inválido. R_INVALID_ID y 0 nunca son handl"
 },
 {
  "t": "Layout y slots",
  "page": "guia.html",
  "hash": "layout",
  "text": "El layout es el de Slate, en dos pasadas: cada widget calcula el tamaño que le gustaría, de abajo arriba; después cada panel reparte rectángulos, de arriba abajo. La colocación de un hijo se guarda en el hijo, en su slot, y la lee su padre."
 },
 {
  "t": "Ventanas",
  "page": "guia.html",
  "hash": "ventanas",
  "text": "Una ventana se crea con un título, un tamaño de cliente y flags:"
 },
 {
  "t": "Eventos y acciones",
  "page": "guia.html",
  "hash": "eventos",
  "text": "Raven tiene dos formas de conectar la interfaz con tu código: acciones por nombre (cómodas desde XML y scripts) y callbacks directos (cómodos desde C)."
 },
 {
  "t": "Memoria e hilos",
  "page": "guia.html",
  "hash": "memoria",
  "text": "Raven no llama a malloc. Toma memoria del sistema en regiones de 4 MB y la reparte con su propio heap TLSF: asignación y liberación en tiempo constante, vecinos libres fusionados. Las fuentes y decodificadores incluidos también lo usan."
 },
 {
  "t": "Animaciones",
  "page": "guia.html",
  "hash": "animaciones",
  "text": "Los controles se mueven solos con springs: los botones se aplastan al pulsarlos y rebotan, los switches se deslizan, los popups salen de lo que los abrió y las listas se estiran en los extremos. Tú solo decides las transiciones y los ajustes globales."
 },
 {
  "t": "Diálogos y archivos",
  "page": "guia.html",
  "hash": "dialogos",
  "text": "En Windows se usan los diálogos comunes; en Linux, zenity o kdialog si están instalados. Si no hay diálogo del sistema, Raven usa el suyo, construido sobre el widget FileBrowser, que también puedes incrustar en cualquier ventana."
 },
 {
  "t": "Viewports",
  "page": "guia.html",
  "hash": "viewports",
  "text": "Un Viewport es el puente entre Raven y tu propio contenido renderizado. Hay tres modos:"
 },
 {
  "t": "Rendimiento",
  "page": "guia.html",
  "hash": "rendimiento",
  "text": "El benchmark incluido ( raven_benchmark, compilado con los tests) mide un árbol grande sin GPU. En la máquina de 2 núcleos usada para el desarrollo, build release:"
 },
 {
  "t": "Problemas frecuentes",
  "page": "guia.html",
  "hash": "problemas",
  "text": ""
 },
 {
  "t": "Una interfaz, escrita una vez",
  "page": "xml.html",
  "hash": "",
  "text": "Referencia completa del XML de Raven: ventana, paneles, controles, herramientas, slots, expresiones, tags propios, documentos y el compilador ravenc (XMLC)."
 },
 {
  "t": "Reglas y tipos de valor",
  "page": "xml.html",
  "hash": "reglas",
  "text": "Un documento XML se carga con Rwindow_create_from_xml_file (raíz <Window> ) o con Rwidget_create_from_xml (cualquier widget como raíz). Los tags son tipos de widget; los atributos, propiedades; los Slot.* son el slot del hijo."
 },
 {
  "t": "La ventana",
  "page": "xml.html",
  "hash": "ventana",
  "text": "<Window> solo puede ser la raíz de Rwindow_create_from_xml[File]. Tiene un hijo de contenido, opcionalmente una <Island> flotante y cualquier número de <Shortcut> y declaraciones <Widget>."
 },
 {
  "t": "Atributos comunes a todo widget",
  "page": "xml.html",
  "hash": "atributos",
  "text": "Un widget tiene un nombre de acción; las cinco variantes On... son sinónimos para legibilidad. La acción se dispara con el evento principal:"
 },
 {
  "t": "Slots",
  "page": "xml.html",
  "hash": "slots",
  "text": "El slot pertenece al hijo y lo lee el panel padre. Cada panel usa los atributos que tienen sentido para él. Los más habituales:"
 },
 {
  "t": "Paneles",
  "page": "xml.html",
  "hash": "paneles",
  "text": ""
 },
 {
  "t": "Controles",
  "page": "xml.html",
  "hash": "controles",
  "text": "Los atajos de un MenuItem funcionan sin necesidad de un <Shortcut>: la ventana los busca en sus menús cuando se pulsan las teclas."
 },
 {
  "t": "Herramientas",
  "page": "xml.html",
  "hash": "herramientas",
  "text": "<Track>: Name, Color, Height, Locked, Muted; contiene <Clip> y <Key>. <Clip>: Start, Length o End, Label, Color, Selected. <Key>: Time, Label, Color. <Marker>: Time, Label, Color."
 },
 {
  "t": "Markdown",
  "page": "xml.html",
  "hash": "markdown",
  "text": "Markdown=\"true\" en un Label renderiza el texto: encabezados, negrita, cursiva, tachado, código, enlaces, listas (con casillas), citas, bloques de código coloreados, tablas, reglas, saltos de línea e imágenes. En un TextEditor, el mismo flag mantiene el texto t"
 },
 {
  "t": "Tags propios",
  "page": "xml.html",
  "hash": "tags",
  "text": "Un documento puede declarar sus propios tags con parámetros y reutilizarlos como cualquier widget de la librería:"
 },
 {
  "t": "XMLC: un archivo, cualquier lenguaje",
  "page": "xml.html",
  "hash": "xmlc",
  "text": "XMLC es la forma de escribir la interfaz y su código en un solo archivo. Los scripts son código normal dentro de <script>; el XML se convierte en tablas que construye Rwindow_create_from_compiled, sin leer XML en tiempo de ejecución. ravenc genera un fuente de"
 },
 {
  "t": "Recarga en vivo",
  "page": "xml.html",
  "hash": "recarga",
  "text": "Una ventana o widget creado desde archivo, los archivos que incluye, los archivos de tags declarados y los archivos de tema se vigilan mientras la aplicación corre. Al guardar, la interfaz sigue estos criterios:"
 },
 {
  "t": "Documentos y herramientas",
  "page": "xml.html",
  "hash": "documentos",
  "text": "Para un editor visual o una herramienta que manipule la interfaz, Raven expone el XML como un árbol de nodos editable:"
 },
 {
  "t": "El aspecto, los materiales y las herramientas",
  "page": "interfaz.html",
  "hash": "",
  "text": "Temas, materiales de cristal, blur, editor de código, docking, isla, herramientas de autor, accesibilidad, idiomas, RTL y páginas web en Raven."
 },
 {
  "t": "Temas y estilos",
  "page": "interfaz.html",
  "hash": "temas",
  "text": "Un tema es lo que da aspecto a cada widget: unos cuarenta colores por rol (no por widget: accent, panel, text …), una veintena de métricas (tamaño de fuente, radio de esquina, altura de control…), un material, una fuente, los colores del código y una lista de "
 },
 {
  "t": "Glass y blur",
  "page": "interfaz.html",
  "hash": "glass",
  "text": "Un material es de lo que está hecha la superficie de un widget. Los temas de cristal son solo un punto de partida: cualquier widget puede pedir su propio material."
 },
 {
  "t": "Editor de texto",
  "page": "interfaz.html",
  "hash": "editor",
  "text": "R_WIDGET_TEXT_EDITOR ( <TextEditor> ) edita texto de cualquier número de líneas: selección, portapapeles, deshacer, números de línea y ajuste de línea. Con un lenguaje colorea el texto, propone palabras mientras se escribe (las del lenguaje y las que ya están "
 },
 {
  "t": "Docking",
  "page": "interfaz.html",
  "hash": "docking",
  "text": "Un DockArea ordena sus hijos como paneles con pestañas. El usuario arrastra una pestaña a otra barra de pestañas, a un lado de un panel o a un borde del área; los paneles vuelan a su nueva posición."
 },
 {
  "t": "La isla",
  "page": "interfaz.html",
  "hash": "isla",
  "text": "Una píldora en la parte superior de la ventana que se despliega bajo el puntero, con un clic, o desde C. Sus dos contenidos se funden mientras cambia de tamaño; un clic la fija abierta y un clic fuera la cierra. Es oscura sea cual sea el tema, como la muesca d"
 },
 {
  "t": "Herramientas de autor",
  "page": "interfaz.html",
  "hash": "herramientas",
  "text": "El header raven_tools.h agrupa los widgets de las herramientas creativas. Cada uno mantiene un modelo pequeño que la aplicación rellena y lee, o que escribe en XML."
 },
 {
  "t": "Accesibilidad",
  "page": "interfaz.html",
  "hash": "accesibilidad",
  "text": "Cada widget es visto por el lector de pantalla del sistema con su rol, nombre, valor y estado, y se puede usar desde él: pulsar, alternar, poner un valor, editar texto y mover el foco. Funciona con UI Automation en Windows (Narrator, NVDA, JAWS), NSAccessibili"
 },
 {
  "t": "Idiomas y RTL",
  "page": "interfaz.html",
  "hash": "idiomas",
  "text": "Las traducciones son tablas CSV: una columna por idioma, cualquier número de tablas, plurales con las reglas CLDR y recarga en vivo al guardar. Un texto que empieza por @ es una clave: el widget sigue el idioma cuando cambia."
 },
 {
  "t": "Páginas web",
  "page": "interfaz.html",
  "hash": "web",
  "text": "raven_web es una librería opcional aparte que muestra páginas HTML, CSS y JavaScript dentro de una interfaz Raven. Raven no depende de ella; una aplicación que la quiere la enlaza junto a Raven ( raven::web, opción RAVEN_BUILD_WEB )."
 },
 {
  "t": "La API pública, sin rodeos",
  "page": "api.html",
  "hash": "",
  "text": "Referencia de la API pública de Raven: núcleo, ventanas, widgets, layout, controles, temas, recursos, XML, herramientas, dibujo, Vulkan y un índice completo de 921 funciones."
 },
 {
  "t": "Núcleo, bucle y memoria",
  "page": "api.html",
  "hash": "nucleo",
  "text": "El header raven_core.h contiene el ciclo de vida, el bucle de frames, los handles, los errores, las acciones, los timers, las tareas y el montón propio de Raven."
 },
 {
  "t": "Ventanas",
  "page": "api.html",
  "hash": "ventanas",
  "text": "raven_window.h abre ventanas nativas con Win32, X11 o Cocoa y expone todo lo que se puede hacer con ellas sin tocar la plataforma."
 },
 {
  "t": "Widgets y layout",
  "page": "api.html",
  "hash": "widgets",
  "text": "El árbol de widgets se conserva entre frames. Un widget nace sin ventana; se muestra cuando se añade a un padre que ya pertenece a una. Rwidget_create recibe un RWidgetType; para los tipos más comunes hay atajos como Rlabel_create, Rbutton_create o Rtext_edito"
 },
 {
  "t": "Controles",
  "page": "api.html",
  "hash": "controles",
  "text": "raven_controls.h es el header más grande después de herramientas: 142 funciones para etiquetas, botones, campos, listas, menús, editores y visores. Todos los controles son widgets normales y aceptan las propiedades comunes."
 },
 {
  "t": "Temas, fuentes y recursos",
  "page": "api.html",
  "hash": "temas",
  "text": "raven_style.h define los roles de color, las métricas, los materiales y la API de temas. raven_resources.h gestiona fuentes, texturas, imágenes y memoria de píxeles."
 },
 {
  "t": "XML y documentos",
  "page": "api.html",
  "hash": "xml",
  "text": "raven_xml.h es a la vez el cargador de interfaces y una API de documentos: se puede leer, recorrer, modificar, serializar y volver a construir un árbol XML sin tocar un archivo. La referencia XML explica los tags y atributos."
 },
 {
  "t": "Herramientas, diálogos y dibujo",
  "page": "api.html",
  "hash": "herramientas",
  "text": "El resto de la API cubre las piezas que convierten a Raven en una base para editores: herramientas creativas, diálogos del sistema, viewports, dibujo inmediato, shaders, Vulkan y backends."
 },
 {
  "t": "Índice completo",
  "page": "api.html",
  "hash": "indice",
  "text": "Las 921 funciones públicas de los headers, agrupadas por área. Escribe para filtrar por nombre, tipo, argumentos o descripción. Los textos de las descripciones vienen de los comentarios de los headers."
 },
 {
  "t": "Raven desde cualquier lenguaje",
  "page": "lenguajes.html",
  "hash": "",
  "text": "Bindings de Raven para C++, Python, Rust, Go, C#, Zig y LuaJIT, el IDE raven_designer, XMLC en cada lenguaje, los ejemplos y las preguntas frecuentes."
 },
 {
  "t": "C++",
  "page": "lenguajes.html",
  "hash": "cpp",
  "text": "El binding de C++ es un solo header, raven.hpp. Da una clase por tipo de handle ( Window, Button, XmlNode …), acepta lambdas donde C pide un callback y añade un Painter para dibujar. Usa los headers de C y enlaza como un programa C, con la librería estática o "
 },
 {
  "t": "Python",
  "page": "lenguajes.html",
  "hash": "python",
  "text": "El binding de Python es un módulo único, raven.py, basado en ctypes y sin dependencias. Los textos son str, los callbacks son funciones de Python y los valores que C devuelve por puntero se convierten en tuplas o resultados."
 },
 {
  "t": "Rust",
  "page": "lenguajes.html",
  "hash": "rust",
  "text": "El binding de Rust es un crate: raven::sys expone la API de C y el crate añade ayudas para &str, CString, acciones y textos. Se puede enlazar la librería compartida (por defecto) o la estática con RAVEN_STATIC=1."
 },
 {
  "t": "Go, C#, Zig y LuaJIT",
  "page": "lenguajes.html",
  "hash": "otros",
  "text": "Los cuatro bindings se generan con el mismo script y cubren la misma API pública, con los nombres de C. La diferencia está en el sistema de tipos y en cómo se registran los callbacks."
 },
 {
  "t": "XMLC en cada lenguaje",
  "page": "lenguajes.html",
  "hash": "xmlc",
  "text": "La interfaz en XML y el código que va con ella en bloques <script>, todo en un archivo. ravenc convierte el archivo entero en una fuente del lenguaje: los scripts se copian tal cual y el XML se transforma en tablas que construye Rwindow_create_from_compiled, s"
 },
 {
  "t": "El IDE",
  "page": "lenguajes.html",
  "hash": "ide",
  "text": "raven_designer.exe es el IDE oficial, construido sobre la propia librería. Se abre con una carpeta de proyecto, un.xml o un archivo.xml*. En el paquete está en bin/."
 },
 {
  "t": "Los ejemplos",
  "page": "lenguajes.html",
  "hash": "ejemplos",
  "text": "El repositorio de Raven incluye dieciséis programas de ejemplo. No vienen en el paquete precompilado, pero cada uno muestra una parte distinta de la librería y sirve como plantilla para empezar."
 },
 {
  "t": "Preguntas frecuentes",
  "page": "lenguajes.html",
  "hash": "faq",
  "text": "Sí. Raven se distribuye bajo Apache License 2.0. Puedes usarlo en proyectos comerciales y privados; conserva el aviso de licencia y, si modificas archivos, indica los cambios. Las licencias de terceros (stb, Roboto, Roboto Mono, tweetnacl) están en share/raven"
 }
];
