/* Navegación compartida del sitio. */
window.RAVEN_NAV = [
  {
    title: "Empezar",
    items: [
      { t: "Introducción", href: "index.html", page: "index.html" },
      { t: "Instalación", href: "guia.html#instalacion", page: "guia.html", hash: "instalacion" },
      { t: "Tu primera ventana", href: "guia.html#primera-ventana", page: "guia.html", hash: "primera-ventana" },
      { t: "El bucle", href: "guia.html#bucle", page: "guia.html", hash: "bucle" },
      { t: "Conceptos básicos", href: "guia.html#conceptos", page: "guia.html", hash: "conceptos" }
    ]
  },
  {
    title: "Guía",
    items: [
      { t: "Layout y slots", href: "guia.html#layout", page: "guia.html", hash: "layout" },
      { t: "Ventanas", href: "guia.html#ventanas", page: "guia.html", hash: "ventanas" },
      { t: "Eventos y acciones", href: "guia.html#eventos", page: "guia.html", hash: "eventos" },
      { t: "Memoria e hilos", href: "guia.html#memoria", page: "guia.html", hash: "memoria" },
      { t: "Animaciones", href: "guia.html#animaciones", page: "guia.html", hash: "animaciones" },
      { t: "Diálogos y archivos", href: "guia.html#dialogos", page: "guia.html", hash: "dialogos" },
      { t: "Viewports", href: "guia.html#viewports", page: "guia.html", hash: "viewports" },
      { t: "Rendimiento", href: "guia.html#rendimiento", page: "guia.html", hash: "rendimiento" }
    ]
  },
  {
    title: "XML",
    items: [
      { t: "Reglas y valores", href: "xml.html#reglas", page: "xml.html", hash: "reglas" },
      { t: "Ventana y atributos", href: "xml.html#ventana", page: "xml.html", hash: "ventana" },
      { t: "Paneles", href: "xml.html#paneles", page: "xml.html", hash: "paneles" },
      { t: "Controles", href: "xml.html#controles", page: "xml.html", hash: "controles" },
      { t: "Herramientas", href: "xml.html#herramientas", page: "xml.html", hash: "herramientas" },
      { t: "Tags propios", href: "xml.html#tags", page: "xml.html", hash: "tags" },
      { t: "XMLC: un archivo", href: "xml.html#xmlc", page: "xml.html", hash: "xmlc" },
      { t: "Recarga en vivo", href: "xml.html#recarga", page: "xml.html", hash: "recarga" }
    ]
  },
  {
    title: "Interfaz",
    items: [
      { t: "Temas y estilos", href: "interfaz.html#temas", page: "interfaz.html", hash: "temas" },
      { t: "Glass y blur", href: "interfaz.html#glass", page: "interfaz.html", hash: "glass" },
      { t: "Editor de texto", href: "interfaz.html#editor", page: "interfaz.html", hash: "editor" },
      { t: "Docking", href: "interfaz.html#docking", page: "interfaz.html", hash: "docking" },
      { t: "Isla", href: "interfaz.html#isla", page: "interfaz.html", hash: "isla" },
      { t: "Herramientas", href: "interfaz.html#herramientas", page: "interfaz.html", hash: "herramientas" },
      { t: "Accesibilidad", href: "interfaz.html#accesibilidad", page: "interfaz.html", hash: "accesibilidad" },
      { t: "Idiomas y RTL", href: "interfaz.html#idiomas", page: "interfaz.html", hash: "idiomas" },
      { t: "Páginas web", href: "interfaz.html#web", page: "interfaz.html", hash: "web" }
    ]
  },
  {
    title: "Referencia",
    items: [
      { t: "API de C", href: "api.html", page: "api.html" },
      { t: "Núcleo y ventanas", href: "api.html#nucleo", page: "api.html", hash: "nucleo" },
      { t: "Widgets y layout", href: "api.html#widgets", page: "api.html", hash: "widgets" },
      { t: "Controles", href: "api.html#controles", page: "api.html", hash: "controles" },
      { t: "Temas y recursos", href: "api.html#temas", page: "api.html", hash: "temas" },
      { t: "XML y documentos", href: "api.html#xml", page: "api.html", hash: "xml" },
      { t: "Herramientas", href: "api.html#herramientas", page: "api.html", hash: "herramientas" },
      { t: "Índice completo", href: "api.html#indice", page: "api.html", hash: "indice" }
    ]
  },
  {
    title: "Ecosistema",
    items: [
      { t: "Otros lenguajes", href: "lenguajes.html", page: "lenguajes.html" },
      { t: "C++", href: "lenguajes.html#cpp", page: "lenguajes.html", hash: "cpp" },
      { t: "Python", href: "lenguajes.html#python", page: "lenguajes.html", hash: "python" },
      { t: "Rust", href: "lenguajes.html#rust", page: "lenguajes.html", hash: "rust" },
      { t: "Go, C#, Zig, Lua", href: "lenguajes.html#otros", page: "lenguajes.html", hash: "otros" },
      { t: "El IDE", href: "lenguajes.html#ide", page: "lenguajes.html", hash: "ide" },
      { t: "Ejemplos", href: "lenguajes.html#ejemplos", page: "lenguajes.html", hash: "ejemplos" },
      { t: "Preguntas frecuentes", href: "lenguajes.html#faq", page: "lenguajes.html", hash: "faq" }
    ]
  }
];
