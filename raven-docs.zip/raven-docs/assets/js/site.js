/* ============================================================
   Raven Docs — comportamiento del sitio
   Sin dependencias. Funciona también abriendo los .html
   directamente desde el disco (file://).
   ============================================================ */
(function () {
  "use strict";

  var current = document.body.getAttribute("data-page") || "index.html";
  var doc = document;
  var $ = function (sel, root) { return (root || doc).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || doc).querySelectorAll(sel)); };
  var esc = function (s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  };

  /* ---------- tema ---------- */
  function applyTheme(theme) {
    doc.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("raven-theme", theme); } catch (e) {}
    var button = $("#theme-toggle");
    if (button) {
      button.innerHTML = theme === "light" ? "&#9789;" : "&#9788;";
      button.title = theme === "light" ? "Cambiar a tema oscuro" : "Cambiar a tema claro";
      button.setAttribute("aria-label", button.title);
    }
  }
  function initialTheme() {
    var saved = null;
    try { saved = localStorage.getItem("raven-theme"); } catch (e) {}
    if (saved === "light" || saved === "dark") return saved;
    return "dark";
  }
  applyTheme(initialTheme());

  /* ---------- menú lateral ---------- */
  function renderNav() {
    var host = $("#sidebar-nav");
    if (!host || !window.RAVEN_NAV) return;
    var html = "";
    window.RAVEN_NAV.forEach(function (group) {
      html += '<div class="side-group"><div class="side-title"><span class="dot"></span>' + esc(group.title) + "</div><nav class=\"side-nav\">";
      group.items.forEach(function (item) {
        var active = item.page === current &&
          ((!item.hash && !location.hash) || (item.hash && location.hash === "#" + item.hash));
        html += '<a href="' + esc(item.href) + '" data-page="' + esc(item.page) + '"' +
          (item.hash ? ' data-hash="' + esc(item.hash) + '"' : "") +
          ' class="' + (active ? "active" : "") + '">' + esc(item.t) + "</a>";
      });
      html += "</nav></div>";
    });
    html += '<div class="side-foot">Raven 0.1.3 &middot; Apache 2.0<br>' +
      '<a href="https://github.com/oscar-soirey/Raven" target="_blank" rel="noopener">GitHub</a> &middot; ' +
      '<a href="https://github.com/oscar-soirey/Raven/issues" target="_blank" rel="noopener">Issues</a></div>';
    host.innerHTML = html;
  }
  renderNav();

  /* ---------- botones del marco ---------- */
  var themeButton = $("#theme-toggle");
  if (themeButton) {
    themeButton.addEventListener("click", function () {
      applyTheme(doc.documentElement.getAttribute("data-theme") === "light" ? "dark" : "light");
    });
  }
  var menuButton = $("#menu-toggle");
  function closeMenu() { doc.body.classList.remove("nav-open"); }
  if (menuButton) {
    menuButton.addEventListener("click", function (event) {
      event.stopPropagation();
      doc.body.classList.toggle("nav-open");
    });
    $$(".sidebar a").forEach(function (a) { a.addEventListener("click", closeMenu); });
    doc.addEventListener("click", function (event) {
      if (!doc.body.classList.contains("nav-open")) return;
      if (!event.target.closest(".sidebar") && !event.target.closest("#menu-toggle")) closeMenu();
    });
  }

  /* ---------- progreso de lectura ---------- */
  var progress = $("#progress");
  function updateProgress() {
    if (!progress) return;
    var height = doc.documentElement.scrollHeight - window.innerHeight;
    var ratio = height > 0 ? (window.pageYOffset || doc.documentElement.scrollTop) / height : 0;
    progress.style.width = Math.max(0, Math.min(1, ratio)) * 100 + "%";
  }
  window.addEventListener("scroll", updateProgress, { passive: true });
  window.addEventListener("resize", updateProgress);
  updateProgress();

  /* ---------- anclas de sección ---------- */
  $$("main h2[id], main h3[id]").forEach(function (heading) {
    var link = doc.createElement("a");
    link.className = "anchor-link";
    link.href = "#" + heading.id;
    link.setAttribute("aria-label", "Enlace a esta sección");
    link.textContent = "#";
    heading.appendChild(link);
  });

  /* ---------- scrollspy ---------- */
  var sideLinks = $$(".side-nav a");
  var currentLinks = sideLinks.filter(function (a) { return a.getAttribute("data-page") === current; });
  var headings = $$("main h2[id], main h3[id]");
  function setActive(link) {
    sideLinks.forEach(function (a) { a.classList.toggle("active", a === link); });
  }
  function spy() {
    if (!currentLinks.length) return;
    var y = (window.pageYOffset || doc.documentElement.scrollTop) + 110;
    var best = null;
    headings.forEach(function (h) {
      if (h.getBoundingClientRect().top + (window.pageYOffset || doc.documentElement.scrollTop) <= y) best = h;
    });
    var link = null;
    if (best) {
      currentLinks.forEach(function (a) {
        if (a.getAttribute("data-hash") === best.id) link = a;
      });
    }
    if (!link) {
      currentLinks.forEach(function (a) { if (!a.getAttribute("data-hash")) link = a; });
      if (!link) link = currentLinks[0];
    }
    if (link) setActive(link);
  }
  var spyTick = false;
  window.addEventListener("scroll", function () {
    if (spyTick) return;
    spyTick = true;
    requestAnimationFrame(function () { spy(); spyTick = false; });
  }, { passive: true });
  spy();

  /* ---------- copiar código ---------- */
  $$(".code").forEach(function (block) {
    var button = doc.createElement("button");
    button.className = "copy";
    button.type = "button";
    button.textContent = "Copiar";
    block.appendChild(button);
    button.addEventListener("click", function () {
      var text = block.querySelector("pre") ? block.querySelector("pre").innerText : "";
      function done() {
        button.textContent = "Copiado";
        button.classList.add("done");
        setTimeout(function () { button.textContent = "Copiar"; button.classList.remove("done"); }, 1600);
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, fallback);
      } else fallback();
      function fallback() {
        var area = doc.createElement("textarea");
        area.value = text;
        area.style.position = "fixed";
        area.style.opacity = "0";
        doc.body.appendChild(area);
        area.select();
        try { doc.execCommand("copy"); done(); } catch (e) {}
        doc.body.removeChild(area);
      }
    });
  });

  /* ============================================================
     Resaltado de sintaxis (ligero, sin dependencias)
     ============================================================ */
  var C_KEYWORDS = "auto break case const continue default do else enum extern for goto if inline register restrict return sizeof static struct switch typedef union volatile while _Alignas _Alignof _Atomic _Bool _Complex _Generic _Imaginary _Noreturn _Static_assert _Thread_local true false NULL".split(" ");
  var C_TYPES = "void char short int long float double signed unsigned size_t uint8_t uint16_t uint32_t uint64_t int8_t int16_t int32_t int64_t bool Rid Ruint".split(" ");
  var CPP_KEYWORDS = C_KEYWORDS.concat("class namespace public private protected template typename using virtual override final noexcept constexpr decltype auto new delete this friend operator".split(" "));
  var RUST_KEYWORDS = "as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while".split(" ");
  var RUST_TYPES = "i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool char str String Vec Option Result Box Rc RefCell".split(" ");
  var GO_KEYWORDS = "break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var true false nil".split(" ");
  var GO_TYPES = "bool string byte rune int int8 int16 int32 int64 uint uint8 uint16 uint32 uint64 uintptr float32 float64 complex64 complex128 error".split(" ");
  var CS_KEYWORDS = "abstract as base break case catch checked class const continue default delegate do else enum event explicit extern false finally fixed for foreach goto if implicit in interface internal is lock namespace new null object operator out override params private protected public readonly ref return sealed sizeof stackalloc static struct switch this throw true try typeof unchecked unsafe using virtual void volatile while var async await".split(" ");
  var CS_TYPES = "bool byte char decimal double float int long sbyte short string uint ulong ushort".split(" ");
  var ZIG_KEYWORDS = "addrspace align allowzero and anyframe anytype asm async await break callconv catch comptime const continue defer else enum errdefer error export extern fn for if inline noalias noinline nosuspend opaque or orelse packed pub resume return linksection struct suspend switch test threadlocal try union unreachable usingnamespace var volatile while true false null undefined".split(" ");
  var ZIG_TYPES = "i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f16 f32 f64 f128 bool void noreturn comptime_int comptime_float anyopaque type".split(" ");
  var PY_KEYWORDS = "and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield match case".split(" ");
  var PY_BUILTINS = "print len range str int float list dict set tuple bool bytes open type isinstance super self cls enumerate zip map filter min max sum abs round sorted reversed".split(" ");
  var LUA_KEYWORDS = "and break do else elseif end false for function goto if in local nil not or repeat return then true until while".split(" ");
  var LUA_TYPES = "string number boolean table function thread userdata".split(" ");
  var BASH_KEYWORDS = "if then else elif fi for while do done case esac function return local export readonly in select until time".split(" ");

  function words(list) {
    return list.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("|");
  }

  function tokenizer(code, regex, classes) {
    var out = "", last = 0, m;
    regex.lastIndex = 0;
    while ((m = regex.exec(code))) {
      if (m.index > last) out += esc(code.slice(last, m.index));
      var cls = "p";
      for (var name in classes) {
        if (m.groups && m.groups[name] !== undefined) { cls = classes[name]; break; }
      }
      out += '<span class="tok-' + cls + '">' + esc(m[0]) + "</span>";
      last = regex.lastIndex;
      if (m[0].length === 0) regex.lastIndex++;
    }
    if (last < code.length) out += esc(code.slice(last));
    return out;
  }

  function highlightC(code) {
    var re = new RegExp(
      "(?<comment>/\\*[\\s\\S]*?\\*/|//[^\\n]*)" +
      "|(?<string>\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')" +
      "|(?<pre>^[ \\t]*#[ \\t]*[A-Za-z_]+)" +
      "|(?<number>\\b(?:0[xX][0-9A-Fa-f]+|\\d+(?:\\.\\d+)?)\\b)" +
      "|(?<keyword>\\b(?:" + words(C_KEYWORDS) + ")\\b)" +
      "|(?<type>\\b(?:" + words(C_TYPES) + ")\\b)" +
      "|(?<func>\\b[A-Za-z_][A-Za-z0-9_]*(?=\\s*\\())", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", pre: "k", number: "n", keyword: "k", type: "t", func: "f" });
  }
  function highlightCpp(code) {
    var re = new RegExp(
      "(?<comment>/\\*[\\s\\S]*?\\*/|//[^\\n]*)" +
      "|(?<string>R\"\\([\\s\\S]*?\\)\"|\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')" +
      "|(?<pre>^[ \\t]*#[ \\t]*[A-Za-z_]+)" +
      "|(?<number>\\b(?:0[xX][0-9A-Fa-f]+|\\d+(?:\\.\\d+)?)\\b)" +
      "|(?<keyword>\\b(?:" + words(CPP_KEYWORDS) + ")\\b)" +
      "|(?<type>\\b(?:" + words(C_TYPES.concat(["std", "string", "vector", "unique_ptr", "shared_ptr"])) + ")\\b)" +
      "|(?<func>\\b[A-Za-z_][A-Za-z0-9_]*(?=\\s*\\())", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", pre: "k", number: "n", keyword: "k", type: "t", func: "f" });
  }
  function highlightRust(code) {
    var re = new RegExp(
      "(?<comment>/\\*[\\s\\S]*?\\*/|//[^\\n]*)" +
      "|(?<string>r#*\"[\\s\\S]*?\"#*|\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])')" +
      "|(?<attr>#!?\\[[^\\]]*\\])" +
      "|(?<number>\\b(?:0[xX][0-9A-Fa-f_]+|\\d[\\d_]*(?:\\.\\d+)?)\\b)" +
      "|(?<keyword>\\b(?:" + words(RUST_KEYWORDS) + ")\\b)" +
      "|(?<type>\\b(?:" + words(RUST_TYPES) + ")\\b)" +
      "|(?<func>\\b[A-Za-z_][A-Za-z0-9_]*(?=\\s*[(!]))", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", attr: "a", number: "n", keyword: "k", type: "t", func: "f" });
  }
  function highlightGo(code) {
    var re = new RegExp(
      "(?<comment>/\\*[\\s\\S]*?\\*/|//[^\\n]*)" +
      "|(?<string>`[^`]*`|\"(?:\\\\.|[^\"\\\\])*\")" +
      "|(?<number>\\b(?:0[xX][0-9A-Fa-f]+|\\d+(?:\\.\\d+)?)\\b)" +
      "|(?<keyword>\\b(?:" + words(GO_KEYWORDS) + ")\\b)" +
      "|(?<type>\\b(?:" + words(GO_TYPES) + ")\\b)" +
      "|(?<func>\\b[A-Za-z_][A-Za-z0-9_]*(?=\\s*\\())", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", number: "n", keyword: "k", type: "t", func: "f" });
  }
  function highlightCSharp(code) {
    var re = new RegExp(
      "(?<comment>/\\*[\\s\\S]*?\\*/|//[^\\n]*)" +
      "|(?<string>@\"(?:[^\"]|\"\")*\"|\\$?\"(?:\\\\.|[^\"\\\\])*\")" +
      "|(?<pre>^[ \\t]*#[ \\t]*[A-Za-z_]+)" +
      "|(?<number>\\b\\d+(?:\\.\\d+)?\\b)" +
      "|(?<keyword>\\b(?:" + words(CS_KEYWORDS) + ")\\b)" +
      "|(?<type>\\b(?:" + words(CS_TYPES) + ")\\b)" +
      "|(?<func>\\b[A-Za-z_][A-Za-z0-9_]*(?=\\s*\\())", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", pre: "k", number: "n", keyword: "k", type: "t", func: "f" });
  }
  function highlightZig(code) {
    var re = new RegExp(
      "(?<comment>//[^\\n]*)" +
      "|(?<string>\"(?:\\\\.|[^\"\\\\])*\")" +
      "|(?<number>\\b(?:0[xX][0-9A-Fa-f]+|\\d+(?:\\.\\d+)?)\\b)" +
      "|(?<keyword>\\b(?:" + words(ZIG_KEYWORDS) + ")\\b)" +
      "|(?<type>\\b(?:" + words(ZIG_TYPES) + ")\\b)" +
      "|(?<func>\\b[A-Za-z_][A-Za-z0-9_]*(?=\\s*\\())", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", number: "n", keyword: "k", type: "t", func: "f" });
  }
  function highlightPython(code) {
    var re = new RegExp(
      "(?<comment>#[^\\n]*)" +
      "|(?<string>[rRbBfFuU]{0,2}(\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'))" +
      "|(?<decorator>@[A-Za-z_][\\w.]*)" +
      "|(?<number>\\b(?:0[xX][0-9A-Fa-f]+|\\d+(?:\\.\\d+)?)\\b)" +
      "|(?<keyword>\\b(?:" + words(PY_KEYWORDS) + ")\\b)" +
      "|(?<type>\\b(?:" + words(PY_BUILTINS) + ")\\b)" +
      "|(?<func>\\b[A-Za-z_][A-Za-z0-9_]*(?=\\s*\\())", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", decorator: "a", number: "n", keyword: "k", type: "t", func: "f" });
  }
  function highlightLua(code) {
    var re = new RegExp(
      "(?<comment>--\\[\\[[\\s\\S]*?\\]\\]|--[^\\n]*)" +
      "|(?<string>\\[\\[[\\s\\S]*?\\]\\]|\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')" +
      "|(?<number>\\b\\d+(?:\\.\\d+)?\\b)" +
      "|(?<keyword>\\b(?:" + words(LUA_KEYWORDS) + ")\\b)" +
      "|(?<type>\\b(?:" + words(LUA_TYPES) + ")\\b)" +
      "|(?<func>\\b[A-Za-z_][A-Za-z0-9_.:]*(?=\\s*\\())", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", number: "n", keyword: "k", type: "t", func: "f" });
  }
  function highlightBash(code) {
    var re = new RegExp(
      "(?<comment>#[^\\n]*)" +
      "|(?<string>\"(?:\\\\.|[^\"\\\\])*\"|'[^']*')" +
      "|(?<variable>\\$\\{?[A-Za-z_][A-Za-z0-9_]*\\}?)" +
      "|(?<number>\\b\\d+\\b)" +
      "|(?<keyword>\\b(?:" + words(BASH_KEYWORDS) + ")\\b)" +
      "|(?<func>^\\s*[A-Za-z_][\\w-]*(?=\\s*\\())", "gm");
    return tokenizer(code, re, { comment: "c", string: "s", variable: "a", number: "n", keyword: "k", func: "f" });
  }
  function highlightCmake(code) {
    var re = /(?<comment>#[^\n]*)|(?<string>"(?:\\.|[^"\\])*")|(?<variable>\$\{[^}]+\})|(?<func>^\s*[A-Za-z_][A-Za-z0-9_]*(?=\s*\())|(?<number>\b\d+(?:\.\d+)?\b)/gm;
    return tokenizer(code, re, { comment: "c", string: "s", variable: "a", func: "f", number: "n" });
  }
  function highlightJson(code) {
    var re = /(?<key>"(?:\\.|[^"\\])*"(?=\s*:))|(?<string>"(?:\\.|[^"\\])*")|(?<number>-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b)|(?<keyword>\b(?:true|false|null)\b)/g;
    return tokenizer(code, re, { key: "a", string: "s", number: "n", keyword: "k" });
  }
  function highlightXml(code) {
    var re = /(?<comment><!--[\s\S]*?-->)|(?<cdata><!\[CDATA\[[\s\S]*?\]\]>)|(?<tag><\/?[A-Za-z_][\w:.-]*|\/?>)|(?<attr>[A-Za-z_][\w:.-]*(?=\s*=))|(?<string>"[^"]*"|'[^']*')/g;
    return tokenizer(code, re, { comment: "c", cdata: "s", tag: "g", attr: "a", string: "s" });
  }
  function highlightCsv(code) {
    var re = /(?<string>"(?:[^"]|"")*")|(?<number>\b-?\d+(?:\.\d+)?\b)/g;
    return tokenizer(code, re, { string: "s", number: "n" });
  }

  function highlight(code, lang) {
    switch (lang) {
      case "c": return highlightC(code);
      case "cpp": return highlightCpp(code);
      case "rust": return highlightRust(code);
      case "go": return highlightGo(code);
      case "csharp": return highlightCSharp(code);
      case "zig": return highlightZig(code);
      case "python": return highlightPython(code);
      case "lua": return highlightLua(code);
      case "bash": case "sh": return highlightBash(code);
      case "cmake": return highlightCmake(code);
      case "json": return highlightJson(code);
      case "xml": case "html": return highlightXml(code);
      case "csv": return highlightCsv(code);
      default: return esc(code);
    }
  }

  $$(".code").forEach(function (block) {
    var code = block.querySelector("pre code");
    if (!code) return;
    var lang = block.getAttribute("data-lang") || "";
    if (!lang) {
      var cls = code.className.match(/language-([\w+-]+)/);
      lang = cls ? cls[1] : "";
    }
    lang = lang.toLowerCase();
    if (lang === "c++") lang = "cpp";
    if (lang === "c#") lang = "csharp";
    var raw = code.textContent.replace(/\n$/, "");
    code.innerHTML = highlight(raw, lang);
  });

  /* ============================================================
     Buscador (Ctrl/Cmd + K)
     ============================================================ */
  var overlay = doc.createElement("div");
  overlay.className = "search-overlay";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-label", "Buscar en la documentación");
  overlay.innerHTML =
    '<div class="search-panel">' +
      '<div class="search-head">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>' +
        '<input id="search-input" type="search" placeholder="Buscar secciones, temas, funciones..." autocomplete="off" spellcheck="false">' +
        '<kbd>Esc</kbd>' +
      '</div>' +
      '<div class="search-results" id="search-results"></div>' +
      '<div class="search-foot"><span>&uarr; &darr; para moverse &middot; Enter para abrir</span><span id="search-count"></span></div>' +
    '</div>';
  doc.body.appendChild(overlay);

  var input = $("#search-input");
  var resultsHost = $("#search-results");
  var countHost = $("#search-count");
  var results = [];
  var selected = 0;

  function pageName(page) {
    var names = {
      "index.html": "Inicio", "guia.html": "Guía", "xml.html": "XML",
      "interfaz.html": "Interfaz", "api.html": "API", "lenguajes.html": "Lenguajes"
    };
    return names[page] || page;
  }

  function search(query) {
    var data = window.RAVEN_SEARCH || [];
    var terms = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (!terms.length) return [];
    var found = data.filter(function (item) {
      var haystack = (item.t + " " + (item.text || "") + " " + pageName(item.page)).toLowerCase();
      return terms.every(function (term) { return haystack.indexOf(term) !== -1; });
    });
    /* Las funciones de la API se buscan en vivo y llevan su consulta a api.html. */
    var api = window.RAVEN_API || [];
    for (var i = 0; i < api.length && found.length < 24; i++) {
      var fn = api[i];
      var hay = (fn.n + " " + fn.d + " " + fn.a + " api").toLowerCase();
      if (!terms.every(function (term) { return hay.indexOf(term) !== -1; })) continue;
      if (found.some(function (item) { return item.q === fn.n; })) continue;
      found.push({ t: fn.n + "()", page: "api.html", hash: "indice", text: fn.d, q: fn.n, api: true });
    }
    return found.slice(0, 24);
  }

  function renderResults(query) {
    results = search(query);
    selected = 0;
    if (!query.trim()) {
      resultsHost.innerHTML = '<div class="search-empty">Escribe para buscar en toda la documentación.<br><span class="small">Prueba <b>glass</b>, <b>XMLC</b>, <b>Rwindow_create</b>, <b>docking</b>...</span></div>';
      countHost.textContent = "";
      return;
    }
    if (!results.length) {
      resultsHost.innerHTML = '<div class="search-empty">Sin resultados para <b>' + esc(query) + "</b>.</div>";
      countHost.textContent = "0 resultados";
      return;
    }
    var html = "";
    results.forEach(function (item, index) {
      var text = item.text || "";
      if (text.length > 130) text = text.slice(0, 130).replace(/\s+\S*$/, "") + "...";
      var href = item.page + (item.q ? "?q=" + encodeURIComponent(item.q) : "") +
        (item.hash ? "#" + item.hash : "");
      html += '<a class="search-result' + (index === 0 ? " sel" : "") + '" href="' + esc(href) + '">' +
        '<span class="where">' + (item.api ? "API · función" : esc(pageName(item.page))) + "</span>" +
        "<b>" + esc(item.t) + "</b>" +
        (text ? "<span>" + esc(text) + "</span>" : "") + "</a>";
    });
    resultsHost.innerHTML = html;
    countHost.textContent = results.length + (results.length === 1 ? " resultado" : " resultados");
  }

  function openSearch() {
    overlay.classList.add("open");
    doc.body.style.overflow = "hidden";
    input.value = "";
    renderResults("");
    setTimeout(function () { input.focus(); }, 20);
  }
  function closeSearch() {
    overlay.classList.remove("open");
    doc.body.style.overflow = "";
  }
  function moveSelection(delta) {
    if (!results.length) return;
    selected = (selected + delta + results.length) % results.length;
    $$(".search-result", resultsHost).forEach(function (el, i) {
      el.classList.toggle("sel", i === selected);
      if (i === selected) el.scrollIntoView({ block: "nearest" });
    });
  }
  function openSelected() {
    if (!results.length) return;
    var item = results[selected];
    closeSearch();
    location.href = item.page + (item.q ? "?q=" + encodeURIComponent(item.q) : "") +
      (item.hash ? "#" + item.hash : "");
  }

  var searchButton = $("#search-open");
  if (searchButton) searchButton.addEventListener("click", openSearch);
  input.addEventListener("input", function () { renderResults(input.value); });
  overlay.addEventListener("click", function (event) { if (event.target === overlay) closeSearch(); });
  doc.addEventListener("keydown", function (event) {
    var key = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && key === "k") {
      event.preventDefault();
      if (overlay.classList.contains("open")) closeSearch(); else openSearch();
      return;
    }
    if (event.key === "Escape") {
      if (overlay.classList.contains("open")) closeSearch();
      closeMenu();
      return;
    }
    if (!overlay.classList.contains("open")) return;
    if (event.key === "ArrowDown") { event.preventDefault(); moveSelection(1); }
    else if (event.key === "ArrowUp") { event.preventDefault(); moveSelection(-1); }
    else if (event.key === "Enter") { event.preventDefault(); openSelected(); }
  });

  /* ============================================================
     Índice completo de la API
     ============================================================ */
  var apiHost = $("#api-index-list");
  if (apiHost && window.RAVEN_API) {
    var apiData = window.RAVEN_API;
    var apiSearch = $("#api-search");
    var apiCount = $("#api-count");
    var groupOrder = ["Núcleo", "Ventanas", "Temas", "Recursos", "Widgets", "Layout", "Controles",
      "Editor de texto", "Shell", "Herramientas", "Diálogos", "Viewport", "Dibujo", "Shaders",
      "XML", "Idiomas", "Accesibilidad", "Vulkan", "Backend", "Host"];

    function renderApi(query) {
      var terms = (query || "").toLowerCase().split(/\s+/).filter(Boolean);
      var shown = 0;
      var html = "";
      groupOrder.forEach(function (group) {
        var items = apiData.filter(function (fn) {
          if (fn.h !== group) return false;
          if (!terms.length) return true;
          var hay = (fn.n + " " + fn.d + " " + fn.a).toLowerCase();
          return terms.every(function (term) { return hay.indexOf(term) !== -1; });
        });
        if (!items.length) return;
        shown += items.length;
        html += '<section class="api-group"><h3>' + esc(group) +
          ' <span class="badge-count">' + items.length + "</span></h3>" +
          '<div class="api-list">';
        items.forEach(function (fn) {
          html += '<div class="api-item"><div class="sig"><span class="rt">' + esc(fn.r) +
            '</span> <span class="fn">' + esc(fn.n) + "</span>(" + esc(fn.a) + ")</div>" +
            (fn.d ? '<div class="desc">' + esc(fn.d) + "</div>" : "") + "</div>";
        });
        html += "</div></section>";
      });
      apiHost.innerHTML = html || '<div class="api-empty">Ninguna función coincide con la búsqueda.</div>';
      if (apiCount) apiCount.textContent = shown + " de " + apiData.length + " funciones";
    }
    var initialApiQuery = "";
    try {
      initialApiQuery = new URLSearchParams(location.search).get("q") || "";
    } catch (e) {
      var match = location.search.match(/[?&]q=([^&]+)/);
      if (match) initialApiQuery = decodeURIComponent(match[1].replace(/\+/g, " "));
    }
    if (apiSearch && initialApiQuery) apiSearch.value = initialApiQuery;
    renderApi(initialApiQuery);
    if (apiSearch) {
      var apiTimer = null;
      apiSearch.addEventListener("input", function () {
        clearTimeout(apiTimer);
        apiTimer = setTimeout(function () { renderApi(apiSearch.value); }, 80);
      });
    }
  }

  /* ---------- año del pie ---------- */
  $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });
})();
